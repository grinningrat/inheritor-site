# INHERITOR — installing the port

Four files. Do them in order; each step is independently testable, so if
something breaks you'll know exactly what caused it.

Assumes you've already run `npx quartz create` (TTRPG template) and that
`npx quartz build --serve` gives you a working stock site at
`http://localhost:8080`. If it doesn't, fix that first — don't debug two
things at once.

Throughout, `<repo>` is your cloned Quartz folder.

---

## Step 1 — The texture

```
cp texture.webp <repo>/quartz/static/texture.webp
```

`custom.scss` references it as `/static/texture.webp`. Nothing else to do.

Keep the original `texture.png` somewhere outside the repo as your master —
this WebP is a derived, lossy, greyscale export and you don't want it to be
the only copy you have.

**Verify:** nothing yet. It'll show up in step 3.

---

## Step 2 — Config

Open `<repo>/quartz.config.yaml` and merge in the four blocks from
`quartz.config.snippet.yaml`:

| Block | What to do |
|---|---|
| `theme.typography` | Replace the template's block entirely |
| `theme.colors` | Replace the template's block entirely |
| `plugins` | **Delete** the `darkmode` entry; **add** the `footer` entry |
| `layout.byPageType` | Add the `index: template: full-width` entry |

Don't paste the whole snippet file over your config — it's fragments, not a
complete config, and the plugins list in particular needs merging rather than
replacing.

Then set your base URL in the same file if `quartz create` didn't:

```yaml
baseUrl: inheritorrpg.com
```

```
npx quartz build --serve
```

**Verify:** the site should now be dark with your palette, set in Alegreya,
and the dark-mode toggle should be gone from the header. Links should be teal.
It will still look like Quartz — the layout is stock. That's expected.

---

## Step 3 — The stylesheet

```
cp custom.scss <repo>/quartz/styles/custom.scss
```

This overwrites whatever the template put there. If you'd already made edits,
diff first.

```
npx quartz build --serve
```

**Verify — this is the big one.** Click through your real content and check:

- [ ] Headings: h1 in IM Fell English SC and blood red, h2 bronze with a
      hairline above it, h3/h4 tracked-out uppercase
- [ ] The run-in h6 still sits inline with the paragraph after it
- [ ] Callouts: your `rule`, `warden`, `example`, `statblock` types all
      picking up their colours
- [ ] Tables: uppercase small-caps headers, bone-coloured first column
- [ ] The `all-small-caps` INHERITOR treatment in body text
- [ ] Paper texture faintly visible over the whole page

Anything on that list that fails is a real bug worth chasing. The sidebar and
on-this-page column will look wrong — that's Part Two, not a bug.

---

## Step 4 — The dice roller

```
cp inheritor-dice.inline.ts <repo>/quartz/components/scripts/
cp InheritorDice.tsx        <repo>/quartz/components/
```

Then register it so it renders on every page. Read
`https://quartz.jzhao.xyz/advanced/creating-components` first — Quartz 5
changed how components are registered, and the exact step depends on your
version. The component file has a note about this.

**Verify:** a vertical "ROLL" handle pinned to the right edge. Press `r`, or
tap it. Then check the things that are easy to break:

- [ ] `3d6 vs 12` → a total, a breakdown, and a verdict
- [ ] Rolling exactly 12 → "success at a cost", not "failure"
- [ ] `3d6 vs 12 adv` → keeps the **lower** of two results (roll-under game;
      this is the single most breakable line in the port)
- [ ] `d20!` → explodes on a 20
- [ ] Enter on an empty field repeats the last command
- [ ] Log survives navigating to another page
- [ ] Drawer goes full-width below 800px and the handle moves to the bottom

Once that passes: **delete the "Desktop Only" callout from your Home page.**
It was never true of the design and it definitely isn't now.

---

## Step 5 — Part Two (the sidebar and TOC)

Scroll to the bottom of `custom.scss`, past the `PART TWO` banner. Sections 5
and 6 carry your design decisions but the selectors are guesses — the explorer
and TOC ship as community plugins and own their own markup.

Method: right-click the sidebar in your local dev site → Inspect → read the
real class names → fix the selectors. The declarations inside the rules are
already correct; you're only correcting what they're attached to.

Two things not to rebuild, because Quartz already does them:

- active-file highlighting
- folder collapse/expand and ancestor tracking

`publish.js` implemented both by hand because Obsidian Publish didn't provide
them. Delete that logic rather than porting it.

Still genuinely yours to rebuild:

- the wordmark + "Playtest · Iron and Blood" subtitle (was a CSS `::before` on
  the nav column; better as a small component now that you can render real
  markup)
- per-group folder colour tints (there's a stub at the bottom of the dice
  script that sets `data-inh-group` — confirm the selector)
- the `wip` / `new` frontmatter badges

---

## Step 6 — Sidenote calibration

Section 9 of `custom.scss` still carries `margin-right: -222px` and a 1700px
breakpoint. Those were measured against Obsidian Publish's column widths and
are meaningless in Quartz's grid.

Decide first whether content pages keep the right sidebar (there's a commented
block in the config snippet). Then measure and set the real numbers. This is
the one part of the port that's genuine design work rather than translation.

---

## What's deliberately not here

- **Stacked panes.** Quartz has no equivalent, so the `.publish-renderer`
  rules and the popstate handler that closed panes are both gone.
- **Ko-fi injection.** It was a script appending to the footer after load.
  Better as a component, or just a link in the footer plugin's links map.
- **The MutationObserver scheduler.** Quartz fires a `nav` event; one listener
  replaces the whole thing.
