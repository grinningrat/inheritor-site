// =============================================================================
// INHERITOR — dice roller component
//
// Renders nothing. Its only job is to get the dice script onto the page; the
// drawer builds its own DOM and appends to <body>, exactly as it did under
// Obsidian Publish.
//
// ⚠ VERSION CAVEAT — READ THIS
// The shape below is the long-standing Quartz component contract
// (afterDOMLoaded + a co-located .inline.ts). Quartz 5 moved layout
// registration into quartz.config.yaml and community components ship as
// plugins, so the import path for `types` or the registration step may differ
// on your version. If this doesn't wire up, check:
//     https://quartz.jzhao.xyz/advanced/creating-components
// The script itself (inheritor-dice.inline.ts) is independent of all that —
// it's plain DOM code listening for Quartz's "nav" event, and it will work
// however you end up getting it onto the page.
// =============================================================================

import { QuartzComponent, QuartzComponentConstructor } from "./types"
import script from "./scripts/inheritor-dice.inline"

const InheritorDice: QuartzComponent = () => null

InheritorDice.afterDOMLoaded = script

export default (() => InheritorDice) satisfies QuartzComponentConstructor
